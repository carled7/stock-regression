from sklearn.preprocessing import PolynomialFeatures
from datetime import datetime
import pandas as pd
import joblib


def predict(data):
    model = joblib.load("models/poly_lin_reg.joblib")

    poly_reg = PolynomialFeatures(degree=5)
    X_poly = poly_reg.fit_transform([[data]])
    prediction = model.predict(X_poly)

    return float(prediction[0].item())


